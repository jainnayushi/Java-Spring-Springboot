package com.ayushi.Task1.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Company {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long compId;

//    @NotNull(message = "Company Name is required")

    @NotBlank(message = "Name is required")
    @Size(min = 3, message = "Company Name should have at least  characters")
    private String compName;

    //@OneToMany(mappedBy = "company", cascade = CascadeType.ALL)
    //private List<Employee> employees;

}
