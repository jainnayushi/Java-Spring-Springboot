package com.ayushi.Task1.exception;

import com.ayushi.Task1.entity.ResponseMessage;
import com.fasterxml.jackson.databind.exc.MismatchedInputException;
import jakarta.validation.ConstraintViolationException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import java.util.HashMap;
import java.util.Map;

@ControllerAdvice
@ResponseStatus
public class RestResponseEntityExceptionHandler extends ResponseEntityExceptionHandler {
    @ExceptionHandler(EmployeeNotFoundException.class)
    public ResponseEntity<ResponseMessage> empNotFoundException(EmployeeNotFoundException exception, WebRequest req) {
        ResponseMessage msg = new ResponseMessage(Boolean.FALSE, exception.getMessage());
        return ResponseEntity.status(HttpStatus.NOT_FOUND).body(msg);
    }

    @ExceptionHandler(CompanyNotFoundException.class)
    public ResponseEntity<ResponseMessage> compNotFoundException(CompanyNotFoundException exception, WebRequest req) {
        ResponseMessage msg = new ResponseMessage(Boolean.FALSE, exception.getMessage());
        return ResponseEntity.status(HttpStatus.NOT_FOUND).body(msg);
    }

    @ExceptionHandler(CustomException.class)
    public ResponseEntity<ResponseMessage> customException(CustomException exception, WebRequest req) {
        System.err.println("In CustomException");
        ResponseMessage msg = new ResponseMessage(Boolean.FALSE, exception.getMessage());
        return ResponseEntity.status(HttpStatus.NOT_FOUND).body(msg);
    }

    @ExceptionHandler(NullPointerException.class)
    public ResponseEntity<ResponseMessage> nullPointerException (NullPointerException exception, WebRequest req) {
        System.err.println("In NullPointerException");
        ResponseMessage msg = new ResponseMessage(Boolean.FALSE, exception.getMessage());
        return ResponseEntity.status(HttpStatus.NOT_FOUND).body(msg);
    }
    @ExceptionHandler(ConstraintViolationException.class)
    public ResponseEntity<Object> handleInvalidArgument(ConstraintViolationException exception) {
        Map<String, String> errorMap = new HashMap<>();
        System.err.println("In ConstraintViolationException");
        ResponseMessage responseMessage = null;
        exception.getConstraintViolations().forEach(violation -> {
            String field = violation.getPropertyPath().toString();
            String message = violation.getMessage();
            errorMap.put(field, message);
        });
        for (Map.Entry<String, String> entry : errorMap.entrySet()) {
            responseMessage = new ResponseMessage(Boolean.FALSE, entry.getValue());
        }
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(responseMessage);
    }

    @ExceptionHandler(MismatchedInputException.class)
    public ResponseEntity<ResponseMessage> mismatchedInputException(MismatchedInputException exception, WebRequest req) {
        System.err.println("In MismatchedInputException.class");
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(new ResponseMessage(Boolean.FALSE, "Mismatched Request JSON Found : Employee data need to be passed properly"));
    }

//    @ExceptionHandler(BadRequestException.class)
//    protected ResponseEntity<ResponseMessage> handleBadRequestException(BadRequestException ex, WebRequest request) {
//        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(new ResponseMessage(Boolean.FALSE, "Invalid Request"));
//    }


}
