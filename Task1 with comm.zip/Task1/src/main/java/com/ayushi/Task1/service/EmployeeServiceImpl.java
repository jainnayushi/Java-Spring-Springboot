package com.ayushi.Task1.service;

import com.ayushi.Task1.entity.Company;
import com.ayushi.Task1.entity.Employee;
import com.ayushi.Task1.exception.CompanyNotFoundException;
import com.ayushi.Task1.exception.CustomException;
import com.ayushi.Task1.exception.EmployeeNotFoundException;
import com.ayushi.Task1.repository.CompanyRepository;
import com.ayushi.Task1.repository.EmployeeRepository;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.List;

@Service
public class EmployeeServiceImpl implements EmployeeService {
    @Autowired
    private EmployeeRepository employeeRepo;
    @Autowired
    private CompanyRepository companyRepo;
    @Autowired
    private ObjectMapper objectMapper;

    @Override
    public Employee saveEmployee(Long compId, String empData, MultipartFile image) throws CompanyNotFoundException, IOException {
        System.err.println(empData);
        Company companyDB = companyRepo.findById(compId)
                .orElseThrow(() -> new CompanyNotFoundException("Company with id " + compId + " not available"));
        Employee emp = objectMapper.readValue(empData, Employee.class);
        if (image.getContentType() != null && !image.getContentType().matches("(?i)(image/png|image/jpeg)")) {
            throw new CustomException("Only PNG/JPEG Content type allowed");
        }
        emp.setEmpImage(image.isEmpty() ? null : image.getBytes());
        emp.setCompany(companyDB);
        return employeeRepo.save(emp);
    }

    @Override
    public List<Employee> getEmployees(Long compId) throws EmployeeNotFoundException, CompanyNotFoundException {
        Company companyDB = companyRepo.findById(compId)
                .orElseThrow(() -> new CompanyNotFoundException("Company with id " + compId + " not available"));
        List<Employee> employees = employeeRepo.findByCompany(companyDB);
        if (employees.isEmpty()) {
            throw new EmployeeNotFoundException("No employee in Company with Id-" + compId + " found");
        }
        return employees;
    }

    @Override
    public Employee getEmployeeById(Long empId, Long compId) throws EmployeeNotFoundException, CompanyNotFoundException {
        Company companyDB = companyRepo.findById(compId)
                .orElseThrow(() -> new CompanyNotFoundException("Company with id " + compId + " not available"));
        Employee employeeDB = employeeRepo.findById(empId)
                .orElseThrow(()->new EmployeeNotFoundException("Employee of Id " + empId + " not available"));
        if (!employeeDB.getCompany().equals(companyDB)) {
            throw new EmployeeNotFoundException("Company of id-" + compId + " does not associate with Employee of id-" + employeeDB.getEmpId());
        }
        return employeeDB;
    }

    @Override
    public byte[] getEmployeeImageById(Long empId, Long compId) throws EmployeeNotFoundException, CompanyNotFoundException {
        Company companyDB = companyRepo.findById(compId)
                .orElseThrow(() -> new CompanyNotFoundException("Company with id " + compId + " not available"));
        Employee employeeDB = employeeRepo.findById(empId)
                .orElseThrow(()->new EmployeeNotFoundException("Employee of Id " + empId + " not available"));
        if (!employeeDB.getCompany().equals(companyDB)) {
            throw new EmployeeNotFoundException("Company of id-" + compId + " does not associate with Employee of id-" + employeeDB.getEmpId());
        }
        return employeeDB.getEmpImage();
    }

    @Override
    public Employee updateEmployee(Long compId, String empData, MultipartFile image) throws CompanyNotFoundException, IOException, EmployeeNotFoundException {
        Employee emp = objectMapper.readValue(empData, Employee.class);
        if (emp.getEmpId()==null) {
            throw new CustomException("Employee Id is required");
        }
        Company companyDB = companyRepo.findById(compId)
                .orElseThrow(() -> new CompanyNotFoundException("Company with id " + compId + " not available"));
        Employee employeeDB = employeeRepo.findById(emp.getEmpId())
                .orElseThrow(() -> new EmployeeNotFoundException("Employee with id " + emp.getEmpId() + " not available"));

        if (!employeeDB.getCompany().equals(companyDB)) {
            throw new EmployeeNotFoundException("Company of id-" + compId + " does not associate with Employee of id-" + emp.getEmpId());
        }
        if (image.getContentType() != null && !image.getContentType().matches("(?i)(image/png|image/jpeg)")) {
            throw new CustomException("Only PNG/JPEG Content type allowed");
        }
        employeeDB.setEmpName(emp.getEmpName());
        employeeDB.setEmpJoiningDate(emp.getEmpJoiningDate());
        employeeDB.setEmpImage(image.isEmpty() ? null : image.getBytes());
        employeeDB.setCompany(companyDB);

        return employeeRepo.save(employeeDB);
    }

    @Override
    public void deleteEmployee(Long empId, Long compId) throws EmployeeNotFoundException, CompanyNotFoundException {
        Company companyDB = companyRepo.findById(compId)
                .orElseThrow(() -> new CompanyNotFoundException("Company with id " + compId + " not available"));
        Employee employeeDB = employeeRepo.findById(empId)
                .orElseThrow(()->new EmployeeNotFoundException("Employee of Id " + empId + " not available"));
        if (!employeeDB.getCompany().equals(companyDB)) {
            throw new EmployeeNotFoundException("Company of id-" + compId + " does not associate with Employee of id-" + employeeDB.getEmpId());
        }
        employeeRepo.deleteById(empId);
    }
}

//    @Override
//    public Employee saveEmployee(Long compId, String empData, MultipartFile image) throws CompanyNotFoundException, IOException {
//        if (companyRepo.existsById(compId)) {
//            Employee emp = objectMapper.readValue(empData, Employee.class);
//            if (emp.getEmpName() == null) {
//                throw new CustomException("Employee Name is required");
//            }
//            if (image.getContentType() != null && !(image.getContentType().equals("image/png") || image.getContentType().equals("image/jpeg"))) {
//                throw new CustomException("Only PNG/JPEG Content type allowed");
//
////                return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(new ResponseMessage(Boolean.FALSE, "Only PNG/JPEG Content type allowed"));
//            }
//            if (!image.isEmpty()) {
//                emp.setEmpImage(image.getBytes());
//                System.err.println(image);
//                System.err.println(image.getBytes());
//            }
//            emp.setCompany(companyRepo.findById(compId).get());
//            System.err.println(emp);
//            return employeeRepo.save(emp);
////            return ResponseEntity.status(HttpStatus.OK).body(new ResponseMessage(Boolean.TRUE, "Employee data Uploaded Successfully"));
//        } else {
//            throw new CompanyNotFoundException("Company with id " + compId + " not available");
//        }
//    }

//..


//    @Override
//    public Employee updateEmployee(Long empId, Long compId, String empData, MultipartFile image) throws CompanyNotFoundException, IOException, EmployeeNotFoundException {
//        Optional<Employee> employeeOptional = employeeRepo.findById(empId);
//        if (employeeOptional.isPresent()) {
//            Employee employeeDB = employeeOptional.get();
//            if (companyRepo.existsById(compId)) {
//                Employee emp = objectMapper.readValue(empData, Employee.class);
//                employeeDB.setEmpId(empId);
//                employeeDB.setCompany(companyRepo.findById(compId).get());
//                if(emp.getEmpName()==null){
//                    employeeDB.setEmpName(employeeDB.getEmpName());
//                }else{
//                    employeeDB.setEmpName(emp.getEmpName());
//                }
//                employeeDB.setEmpJoiningDate(emp.getEmpJoiningDate());
//                if (image.getContentType() != null && !(image.getContentType().equals("image/png") || image.getContentType().equals("image/jpeg"))) {
//                    throw new CustomException("Only PNG/JPEG Content type allowed");
////                    return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
////                            .body(new ResponseMessage(Boolean.FALSE, "Only PNG/JPEG Content type allowed"));
//                }
//                if (image.isEmpty()) {
//                    employeeDB.setEmpImage(null);
//                    System.err.println("was empty");
//                } else {
//                    employeeDB.setEmpImage(image.getBytes());
//                }
//                return employeeRepo.save(employeeDB);
////                return ResponseEntity.status(HttpStatus.OK).body(new ResponseMessage(Boolean.TRUE, "Employee data Updated successfully"));
//            } else {
//                throw new CompanyNotFoundException("Company with id " + compId + " not available");
//            }
//        } else {
//            throw new EmployeeNotFoundException("Employee with id " + empId + " not available");
//        }
//    }

//    @Override
//    public Employee updateEmployee(Long compId, String empData, MultipartFile image) throws CompanyNotFoundException, IOException, EmployeeNotFoundException {
//        Employee emp = objectMapper.readValue(empData, Employee.class);
//
//        Optional<Company> companyOptional = companyRepo.findById(compId);
//        if (companyOptional.isPresent()) {
//            Company companyDB = companyOptional.get();
//            Optional<Employee> employeeOptional = employeeRepo.findById(emp.getEmpId());
//            if (employeeOptional.isPresent()) {
//                Employee employeeDB = employeeOptional.get();
//                if (employeeDB.getCompany().equals(companyRepo.findById(compId).get())) {
//                    employeeDB.setCompany(companyRepo.findById(compId).get());
//                    employeeDB.setEmpName(emp.getEmpName());
//                    employeeDB.setEmpJoiningDate(emp.getEmpJoiningDate());
//                    if (image.getContentType() != null && !(image.getContentType().equals("image/png") || image.getContentType().equals("image/jpeg"))) {
//                        throw new CustomException("Only PNG/JPEG Content type allowed");
//                    }
//                    if (image.isEmpty()) {
//                        employeeDB.setEmpImage(null);
//                        System.err.println("was empty");
//                    } else {
//                        employeeDB.setEmpImage(image.getBytes());
//                    }
//                    return employeeRepo.save(employeeDB);
//                } else {
//                    throw new EmployeeNotFoundException("Company of id-" + compId + " does not associate with Employee of id-" + emp.getEmpId());
//                }
//            } else {
//                throw new CompanyNotFoundException("Employee with id " + emp.getEmpId() + " not available");
//            }
//        } else {
//            throw new EmployeeNotFoundException("Company with id " + compId + " not available");
//        }
//    }