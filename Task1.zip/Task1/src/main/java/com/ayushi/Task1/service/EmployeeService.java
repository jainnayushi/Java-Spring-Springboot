package com.ayushi.Task1.service;

import com.ayushi.Task1.entity.Employee;
import com.ayushi.Task1.exception.EmployeeNotFoundException;

import java.util.List;

public interface EmployeeService {
    public Employee addEmployee(Employee emp);

    public List<Employee> getEmployees();

    public Employee getEmployeeById(Long id) throws EmployeeNotFoundException;

    public Employee updateEmployee(Long id, Employee emp);

    public void deleteEmployee(Long id) throws EmployeeNotFoundException;

}
