package com.ayushi.Task1.controller;

import com.ayushi.Task1.entity.Employee;
import com.ayushi.Task1.exception.EmployeeNotFoundException;
import com.ayushi.Task1.service.EmployeeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class EmployeeController {
    @Autowired
    private EmployeeService employeeService;

    @PostMapping("/emp")
    public Employee addEmployee(@RequestBody Employee emp) {
        return employeeService.addEmployee(emp);
    }

    @GetMapping("/emps")
    public List<Employee> getEmployees() {
        return employeeService.getEmployees();
    }

    @GetMapping("/emp/{id}")
    public Employee getEmployeeById(@PathVariable("id") Long id) throws EmployeeNotFoundException {
        return employeeService.getEmployeeById(id);
    }

    @PutMapping("/emp/{id}")
    public Employee updateEmployee(@PathVariable("id") Long id, @RequestBody Employee emp) {
        return employeeService.updateEmployee(id, emp);
    }

    @DeleteMapping("/emp/{id}")
    public String deleteEmployee(@PathVariable("id") Long id) throws EmployeeNotFoundException {
        employeeService.deleteEmployee(id);
        return "Record with id " + id + " is deleted!";
    }

}
