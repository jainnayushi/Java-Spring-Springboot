package com.ayushi.Task1.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Company {
    @Id
    //@GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long CompId;
    private String CompName;

    //@OneToMany(mappedBy = "company", cascade = CascadeType.ALL)
    //private List<Employee> employees;
}
