package com.ayushi.Task1.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class Employee {
    @Id
    //@GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long empId;

    @NotNull(message = "Name is required")
    @Size(min = 3, message = "Name should have at least 3 characters")
    private String empName;

    @PastOrPresent(message = "Joining date should be today or older")
    private LocalDate empJoiningDate;

    @ManyToOne
    @JoinColumn(name = "comp_id")
    @NotNull(message = "Company is required")
    private Company company;

}

