package com.ayushi.Task1.controller;

import com.ayushi.Task1.entity.Company;
import com.ayushi.Task1.exception.CompanyNotFoundException;
import com.ayushi.Task1.service.CompanyService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class CompanyController {
    @Autowired
    private CompanyService companyService;

    @PostMapping("/comp")
    public Company addCompany(@RequestBody Company comp) {
        return companyService.addCompany(comp);
    }

    @GetMapping("/comps")
    public List<Company> getCompanies() {
        return companyService.getCompanies();
    }

    @GetMapping("/comp/{id}")
    public Company getCompanyById(@PathVariable("id") Long id) throws CompanyNotFoundException {
        return companyService.getCompanyById(id);
    }

    @PutMapping("/comp/{id}")
    public Company updateCompany(@PathVariable("id") Long id, @RequestBody Company comp) {
        return companyService.updateCompany(id, comp);
    }

    @DeleteMapping("/comp/{id}")
    public String deleteCompany(@PathVariable("id") Long id) throws CompanyNotFoundException {
        companyService.deleteCompany(id);
        return "Record with id " + id + " is deleted!";
    }

    @DeleteMapping("/comps")
    public String deleteAllCompany() {
        companyService.deleteAllCompany();
        return "Records deleted!";
    }
}
