package com.ayushi.Task1.service;

import com.ayushi.Task1.entity.Company;
import com.ayushi.Task1.exception.CompanyNotFoundException;

import java.util.List;

public interface CompanyService {
    public Company addCompany(Company comp);

    public List<Company> getCompanies();

    public Company getCompanyById(Long id) throws CompanyNotFoundException;

    public Company updateCompany(Long id, Company comp);

    public void deleteCompany(Long id) throws CompanyNotFoundException;

    public void deleteAllCompany();
}
