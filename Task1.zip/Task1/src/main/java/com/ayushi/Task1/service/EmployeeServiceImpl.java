package com.ayushi.Task1.service;

import com.ayushi.Task1.entity.Employee;
import com.ayushi.Task1.exception.EmployeeNotFoundException;
import com.ayushi.Task1.repository.EmployeeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Objects;
import java.util.Optional;

@Service
public class EmployeeServiceImpl implements EmployeeService {
    @Autowired
    private EmployeeRepository employeeRepo;

    @Override
    public Employee addEmployee(Employee emp) {
        return employeeRepo.save(emp);
    }

    @Override
    public List<Employee> getEmployees() {
        return employeeRepo.findAll();
    }

    @Override
    public Employee getEmployeeById(Long id) throws EmployeeNotFoundException {
        Optional<Employee> emp = employeeRepo.findById(id);
        if (!emp.isPresent()) {
            throw new EmployeeNotFoundException("Employee of this Id " + id + " is not found");
        }
        return emp.get();
    }

    @Override
    public Employee updateEmployee(Long id, Employee emp) {
        Employee empDB = employeeRepo.findById(id).get();
        if (Objects.nonNull(emp.getEmpName()) && !"".equalsIgnoreCase(emp.getEmpName())) {
            empDB.setEmpName(emp.getEmpName());
        }
        if (Objects.nonNull(emp.getEmpJoiningDate()) && !"".equalsIgnoreCase(String.valueOf(emp.getEmpJoiningDate()))) {
            empDB.setEmpJoiningDate(emp.getEmpJoiningDate());
        }
        return employeeRepo.save(empDB);
    }

    @Override
    public void deleteEmployee(Long id) throws EmployeeNotFoundException {
        Optional<Employee> emp = employeeRepo.findById(id);
        if (!emp.isPresent()) {
            throw new EmployeeNotFoundException("Employee of Id " + id + " is not found");
        }
        employeeRepo.deleteById(id);
    }
}
