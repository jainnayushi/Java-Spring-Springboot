//package com.ayushi.Task1.extra;
//
//public interface PostValidationGroup {
//}
