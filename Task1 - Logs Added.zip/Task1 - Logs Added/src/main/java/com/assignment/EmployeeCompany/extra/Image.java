//package com.ayushi.Task1.extra;
//
//import jakarta.persistence.*;
//import lombok.AllArgsConstructor;
//import lombok.Builder;
//import lombok.Data;
//import lombok.NoArgsConstructor;
//
//@Entity
//@Data
//@NoArgsConstructor
//@AllArgsConstructor
//@Builder
//public class Image {
//    @Id
//    @GeneratedValue
//    private int id;
//
//    @Lob
////    @Column(name = "image", nullable = false, columnDefinition = "mediumblob")
//    private byte[] image;
//
//    private String data;
//
//
//}
