package com.assignment.EmployeeCompany;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmployeeCompanyApplication {

    public static void main(String[] args) {
        SpringApplication.run(EmployeeCompanyApplication.class, args);
        System.err.println("Started....");
    }

}