//package com.ayushi.Task1.extra;
//
//import com.ayushi.Task1.extra.Image;
//import org.springframework.data.jpa.repository.JpaRepository;
//import org.springframework.stereotype.Repository;
//
//@Repository
//public interface ImageRepository extends JpaRepository<Image, Integer> {
//}
