package com.assignment.EmployeeCompany.exception;

public class CustomException extends RuntimeException {
    public CustomException(String message) {
        super(message);
    }
}